<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Log in</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <?= $this->Html->css(['all.min', 'icheck-bootstrap.min', 'adminlte.min']) ?>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="#"><b>Login</a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
  <?= $this->fetch('content') ?>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<?=$this->Html->script(['jquery.min','bootstrap.bundle.min','adminlte','demo','dashboard3']);?>
</body>
</html>
