

    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <?= $this->Form->create() ?>
        <div class="input-group mb-3">
        <?= $this->Form->control('username',['class'=>'form-control']) ?>
        </div>
        <div class="input-group mb-3">
        <?= $this->Form->control('password',['class'=>'form-control']) ?>
        </div>
        <div class="row">
          <!-- /.col -->
          <div class="col-4">
          <?= $this->Form->submit(); ?>
          </div>
          <!-- /.col -->
        </div>
        <?= $this->Form->end() ?>
    </div>
