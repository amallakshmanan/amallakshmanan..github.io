function showmenu() {
    var element = document.getElementById("menu-toggle-id");
    element.classList.toggle("show-menu");
    var element = document.getElementById("menu-open-id");
    element.classList.toggle("menu-close");
    var element = document.getElementById("mainmenu-open");
    element.classList.toggle("mainmenu-open");
    var element = document.getElementById("logo");
    element.classList.toggle("logo-menu");
    var element = document.getElementById("header");
    element.classList.toggle("img-none");




}