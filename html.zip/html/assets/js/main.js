$(document).ready(function() {
    // Add smooth scrolling to all links
    $("a").on('click', function(event) {

        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
            // Prevent default anchor click behavior
            event.preventDefault();

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 800, function() {

                // Add hash (#) to URL when done scrolling (default click behavior)
                window.location.hash = hash;
            });
        } // End if
    });
});



$('.more-button').click(function() {
    $('.moretext1').slideToggle();
    if ($('.more-button').text() == "read more") {
        $(this).text("read less")
    } else {
        $(this).text("read more")
    }
});

$('.more-button1').click(function() {
    $('.moretext2').slideToggle();
    if ($('.more-button1').text() == "read more") {
        $(this).text("read less")
    } else {
        $(this).text("read more")
    }
});

$('.moreless-button').click(function() {
    $('.moretext').slideToggle();
    if ($('.moreless-button').text() == "show more") {
        $(this).text("show less")
    } else {
        $(this).text("show more")
    }
});

















function getBroVol() {
    var b = 0,
        a = 0,
        c = {};
    if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        b = document.documentElement.clientWidth;
        a = document.documentElement.clientHeight
    } else {
        if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
            b = document.body.clientWidth;
            a = document.body.clientHeight
        } else {
            if (document.body && document.body.offsetWidth) {
                b = document.body.offsetWidth;
                a = document.body.offsetHeight
            } else {
                if (document.compatMode == "CSS1Compat" && document.documentElement && document.documentElement.offsetWidth) {
                    b = document.documentElement.offsetWidth;
                    a = document.documentElement.offsetHeight
                }
            }
        }
    }
    this.h = a;
    this.w = b;
    return
}

function broW() {
    return new getBroVol().w
}
var winW = broW(),
    winH = new getBroVol().h,
    h_heig = 0,
    res, testimSlider;
var base_url = window.location.protocol + "//" + window.location.host + "/" + window.location.pathname.split('/')[1];
$(window).scrollTop(0)
$(window).on("resize", function(a) {
    a.preventDefault();
    if (res) {
        clearTimeout(res)
    }

}).trigger('resize');
$(window).scroll(function() {
    scrolTop = $(this).scrollTop()
    if ($(this).scrollTop() >= 400) {
        $('.scrollToTop').addClass('act');
    } else {
        $('.scrollToTop').removeClass('act');
    }
    if (scrolTop > 25) {
        $('header').addClass('hdr-act');
        $('header').removeClass('act');
    } else if (scrolTop == 0) {
        $('header').removeClass('hdr-act');
        $('header').addClass('act');
    }




}).trigger('scroll');



  $(document).ready(function () {


    $(window).on("scroll", function () {
        console.log($(this).scrollTop())
        if ($(window).width() >= 992) {
            if ($(this).scrollTop() >= 30) {
                // set to new image
                $(".navbar-brand img").attr("src", "assets/images/logob.png");
            } 
        }
    })
	$(window).on("scroll", function () {
        console.log($(this).scrollTop())
        if ($(window).width() >= 992) {
            if ($(this).scrollTop() < 30) {
                // set to new image
                $(".navbar-brand img").attr("src", "assets/images/logo.png");
            } 
        }
    })
    
	
})




